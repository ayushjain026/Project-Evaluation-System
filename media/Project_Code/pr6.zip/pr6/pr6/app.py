from flask import Flask

UPLOAD_FOLDER = 'D:/College/SEM_6/DSML/PRACTICALS/6/pr6/pr6/uploads'

app = Flask(__name__,template_folder='template')
app.secret_key = "secret key"
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER